local rankUpService = game:GetService("ReplicatedStorage").RankUpService

while true do
    rankUpService.OnClientEvent:Connect(function()
        rankUpService:FireServer()
    end)
    wait(1)
end