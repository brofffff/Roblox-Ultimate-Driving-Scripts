game.Players.LocalPlayer.PlayerScripts.leaderstats.Cash.Value = math.huge
game.Players.LocalPlayer.PlayerScripts.leaderstats.Cash.Changed:Connect(function() end)