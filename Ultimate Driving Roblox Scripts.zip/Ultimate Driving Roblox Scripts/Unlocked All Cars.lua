local carCatalog = game:GetService("CollectionService"):GetTagged("Car")
for _, car in ipairs(carCatalog:GetChildren()) do
    local carInstance = car:FindFirstChild("Car")
    if carInstance then
        local owner = carInstance.Owner
        if owner then
            owner.Value = game.Players.LocalPlayer
            owner.Parent = carInstance
        end
    end
end